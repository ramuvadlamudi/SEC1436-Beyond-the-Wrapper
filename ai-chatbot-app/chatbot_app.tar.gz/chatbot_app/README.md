# AI Chatbot for Splunk — Setup Guide

This package is a complete, working Splunk app: a chat interface for
analysts, backed by a local LLM, with real multi-turn memory via a KV
store. This is v2 — updated after a security/functionality review of
the initial pilot. See the changelog at the bottom for what changed.

## What's in this folder

| File | What it is |
|---|---|
| `default/app.conf` | Tells Splunk "this folder is an app" and what to call it |
| `default/collections.conf` | Creates the KV store used to remember conversations (now includes an `owner` field for session ownership) |
| `default/commands.conf` | Registers the `ollamachat` command and the new `ollamachatcleanup` retention command |
| `default/ai_chatbot_settings.conf` | **All configuration lives here now** — Ollama URL, model, timeouts, history/message limits, grounding settings |
| `default/savedsearches.conf` | Schedules the daily session-cleanup job |
| `default/metadata/default.meta` | Permissions — tightened in v2, scoped to a named role instead of everyone |
| `default/data/ui/nav/default.xml` | Puts a link to the chatbot in this app's menu |
| `default/data/ui/views/chatbot.xml` | The chatbot dashboard |
| `appserver/static/chat.js` | Chat UI logic — now with a loading indicator and double-submit guarding |
| `appserver/static/chat.css` | Chat window styling |
| `bin/ollamachat.py` | The main bridge to your LLM — system prompt handling, grounding, session ownership |
| `bin/cleanup_sessions.py` | Deletes old conversations per the configured retention period |

## Required configuration

Unlike v1, you no longer edit the Python file directly. Configuration
lives in `default/ai_chatbot_settings.conf`:

```ini
[settings]
ollama_url = http://<ollama-host-internal-ip>:11434/api/chat
default_model = qwen2.5:32b
request_timeout_seconds = 120
max_history_turns = 10
max_message_length = 4000
retention_days = 30
enable_grounding = true
grounding_index = notable
grounding_max_results = 5
```

Replace `<ollama-host-internal-ip>` with your actual LLM connection
address, and adjust `default_model` to match. For a production
deployment, put your overrides in a `local/ai_chatbot_settings.conf`
file instead of editing `default/` directly — that's the standard
Splunk pattern and survives app upgrades.

**Also check `default/metadata/default.meta`** — the KV store and
command permissions are scoped to a role called `user` by default.
Replace this with whatever role your analysts actually hold (several
Defence-specific role names came up during initial testing —
`ess_analyst`, `ess_user`, etc. — use whichever applies in your
environment).

**About grounding:** with `enable_grounding = true`, every question
triggers a keyword search against `grounding_index` (default: `notable`)
before the LLM is called. If your environment doesn't have that index,
or the searching user doesn't have access to it, this fails silently
and the chat still works — just without the extra context. Set
`enable_grounding = false` to disable it entirely.

## Deploying it

1. Install the app (Splunk Web → Install app from file, or extract
   directly into `$SPLUNK_HOME/etc/apps/` over SSH).
2. Edit `ai_chatbot_settings.conf` (or better, add a `local/` override)
   with your real Ollama address.
3. Review `default/metadata/default.meta` and adjust the role name to
   match your environment.
4. Restart Splunk — required for the new command (`ollamachatcleanup`),
   the KV store schema change (`owner` field), and the scheduled
   cleanup search to register.
5. Test the backend directly before touching the dashboard, from
   *inside* the app's own context:
   ```
   | ollamachat session_id="test1" user_message="hello"
   ```
6. Confirm the scheduled cleanup is registered: Settings → Searches,
   Reports, and Alerts → look for "AI Chatbot - Session Cleanup".

## If something doesn't work

- **`Unknown search command`** — test from inside the AI Chatbot app's
  own context, not Search & Reporting; commands are app-scoped by
  default.
- **`ModuleNotFoundError: No module named 'splunklib'`** — vendor the
  Splunk Python SDK's `splunklib` folder into `bin/` (not every Splunk
  build ships it).
- **Command registered but still "unknown"** — check
  `commands.conf` has `generating = true` for both commands; this is
  required for a `GeneratingCommand` to be valid as the first command
  after a pipe.
- **Grounding search fails/errors** — check the searching user has
  access to `grounding_index`, and that the index name is correct for
  your environment. This is designed to fail gracefully (chat still
  works without grounding), so an error here shouldn't break the whole
  command — if it does, check `search.log` for what actually happened.
- **Old conversations not being cleaned up** — check the scheduled
  search is enabled (`enableSched = 1` in `savedsearches.conf`) and
  actually ran (Activity → Jobs, or the saved search's own history).

## v2 Changelog — Addressing Review Feedback

A review of the v1 pilot surfaced several gaps before wider Defence rollout. Here's what changed and what's still open:

**Fixed:**
- **System prompt persistence bug** — previously only injected on the first turn and never stored, so it silently disappeared from every turn after that. Now stored as `turn_index 0` and always included.
- **Basic grounding** — before calling the LLM, the command now runs a keyword-based search against a configurable index (default: ES notables) and injects matching results as context. This is deliberately simple (keyword match, not embeddings/semantic search) — a real first step toward "grounded in the SOC's own knowledge," not a finished RAG system.
- **Session ownership** — every KV store row is now tagged with the authenticated Splunk username, and reads are filtered by `session_id` + `owner` together. A guessed or shared `session_id` can no longer be used to read someone else's conversation through this command.
- **KV store permissions tightened** — collection access is now scoped to a named role (`user` by default — replace with your actual analyst role) instead of `*`.
- **Configuration moved out of Python** — see "Required configuration" above.
- **Retention** — a new `ollamachatcleanup` command + a daily scheduled search now actually deletes sessions older than `retention_days` (previously mentioned in docs but not implemented).
- **Conversation history capping** — long conversations are now truncated to the most recent `max_history_turns` before being sent to the model.
- **Loading state + request guarding** — "Thinking..." indicator, disabled input while a request is in flight, and search jobs are cancelled once read instead of left orphaned.
- **Better escaping** — multiline input and tabs no longer risk breaking the generated SPL string.
- **Basic code-block rendering** — replies wrapped in ```` ``` ```` now render as readable code blocks.
- **Input length limit** and **basic structured logging** (errors via Python's `logging`, plus a `latency_ms` field on every response).

**Still open (roadmap):**
- Streaming responses (Ollama supports it; would improve perceived latency)
- Real retrieval/RAG beyond keyword search
- Exposed sampling parameters (temperature, etc.) as command options
- Admin/audit dashboard for reviewing past conversations
- A proper setup UI instead of editing `.conf` files directly
- A metrics dashboard visualising `latency_ms` and `grounded` over time
