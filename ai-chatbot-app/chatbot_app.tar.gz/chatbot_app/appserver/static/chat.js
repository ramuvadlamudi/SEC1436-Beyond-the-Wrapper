// This file runs in the browser when someone opens the chatbot dashboard.
//
// v2.2 changes:
//   - Checks live LLM status on load (via | ollamachatstatus) and shows
//     a real status badge instead of assuming it's always available.
//   - Renders headers, bold text, and numbered/bulleted lists from the
//     model's reply, not just code blocks — replies were coming back as
//     one dense, hard-to-read paragraph before.
//   - Em dash removed from the greeting text (matches the same change
//     made in ollamachat.py's GREETING_RESPONSE_TEXT — keep these two
//     in sync by hand if either changes again).

require([
    "splunkjs/mvc/searchmanager",
    "splunkjs/mvc/simplexml/ready!"
], function (SearchManager) {

    var sessionId = generateSessionId();
    var requestInFlight = false;

    function generateSessionId() {
        return "sess-" + Date.now() + "-" + Math.floor(Math.random() * 100000);
    }

    function escapeForSPL(text) {
        return text
            .replace(/\\/g, "\\\\")
            .replace(/"/g, '\\"')
            .replace(/\r\n/g, "\\n")
            .replace(/\n/g, "\\n")
            .replace(/\r/g, "\\n")
            .replace(/\t/g, "    ");
    }

    // Escapes text for safe insertion as HTML content (used inside the
    // markdown-lite renderer below, since that builds innerHTML strings
    // rather than using textContent throughout).
    function escapeHtml(text) {
        var div = document.createElement("div");
        div.textContent = text;
        return div.innerHTML;
    }

    // Small, deliberately limited markdown-ish renderer — not a full
    // parser, just enough to make typical LLM output (headers, bold,
    // numbered/bulleted lists, code fences) readable instead of one
    // dense run-on paragraph. Processes the reply block by block.
    function renderReplyContent(container, text) {
        var codeParts = text.split(/```/);

        codeParts.forEach(function (part, index) {
            if (index % 2 === 1) {
                var pre = document.createElement("pre");
                pre.className = "chat-code-block";
                pre.textContent = part.trim();
                container.appendChild(pre);
                return;
            }

            var lines = part.split("\n");
            var listBuffer = null; // {type: 'ul'|'ol', el: <ul>/<ol>}

            function flushList() {
                if (listBuffer) {
                    container.appendChild(listBuffer.el);
                    listBuffer = null;
                }
            }

            lines.forEach(function (rawLine) {
                var line = rawLine.trim();

                if (line.length === 0) {
                    flushList();
                    return;
                }

                var headerMatch = line.match(/^(#{1,4})\s+(.*)$/);
                var numberedMatch = line.match(/^\d+[.)]\s+(.*)$/);
                var bulletMatch = line.match(/^[-*]\s+(.*)$/);

                if (headerMatch) {
                    flushList();
                    var level = Math.min(headerMatch[1].length + 3, 6); // ### -> h4-ish
                    var h = document.createElement("div");
                    h.className = "chat-heading chat-heading-" + level;
                    h.innerHTML = inlineFormat(headerMatch[2]);
                    container.appendChild(h);
                } else if (numberedMatch) {
                    if (!listBuffer || listBuffer.type !== "ol") {
                        flushList();
                        listBuffer = { type: "ol", el: document.createElement("ol") };
                        listBuffer.el.className = "chat-bullet-list";
                    }
                    var li1 = document.createElement("li");
                    li1.innerHTML = inlineFormat(numberedMatch[1]);
                    listBuffer.el.appendChild(li1);
                } else if (bulletMatch) {
                    if (!listBuffer || listBuffer.type !== "ul") {
                        flushList();
                        listBuffer = { type: "ul", el: document.createElement("ul") };
                        listBuffer.el.className = "chat-bullet-list";
                    }
                    var li2 = document.createElement("li");
                    li2.innerHTML = inlineFormat(bulletMatch[1]);
                    listBuffer.el.appendChild(li2);
                } else {
                    flushList();
                    var p = document.createElement("div");
                    p.className = "chat-paragraph";
                    p.innerHTML = inlineFormat(line);
                    container.appendChild(p);
                }
            });

            flushList();
        });
    }

    // Handles **bold** and `inline code` within a single line. Escapes
    // the surrounding text first so nothing else in it is interpreted
    // as HTML, then applies the two patterns.
    function inlineFormat(line) {
        var escaped = escapeHtml(line);
        escaped = escaped.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
        escaped = escaped.replace(/`(.+?)`/g, "<code>$1</code>");
        return escaped;
    }

    // Every message is wrapped in a .chat-turn div, which is what the
    // CSS uses to center each turn within the readable column and
    // right-align user messages within it.
    function appendBubble(role, text) {
        var chatWindow = document.getElementById("chat-window");
        var turn = document.createElement("div");
        turn.className = "chat-turn" + (role === "user" ? " user-turn" : "");

        var bubble = document.createElement("div");
        bubble.className = "chat-bubble " + role;
        if (role === "assistant") {
            renderReplyContent(bubble, text);
        } else {
            bubble.textContent = text;
        }
        turn.appendChild(bubble);
        chatWindow.appendChild(turn);
        chatWindow.scrollTop = chatWindow.scrollHeight;
        return bubble;
    }

    function appendThinkingIndicator() {
        var chatWindow = document.getElementById("chat-window");
        var turn = document.createElement("div");
        turn.className = "chat-turn";
        turn.id = "thinking-indicator";

        var bubble = document.createElement("div");
        bubble.className = "chat-bubble assistant thinking";
        bubble.textContent = "Thinking...";
        turn.appendChild(bubble);
        chatWindow.appendChild(turn);
        chatWindow.scrollTop = chatWindow.scrollHeight;
    }

    function removeThinkingIndicator() {
        var el = document.getElementById("thinking-indicator");
        if (el) {
            el.parentNode.removeChild(el);
        }
    }

    function setInputEnabled(enabled) {
        document.getElementById("chat-input").disabled = !enabled;
        document.getElementById("send-btn").disabled = !enabled;
    }

    function sendMessage(userText) {
        if (requestInFlight) {
            return;
        }
        requestInFlight = true;
        setInputEnabled(false);

        appendBubble("user", userText);
        appendThinkingIndicator();

        var spl = '| ollamachat session_id="' + sessionId +
                   '" user_message="' + escapeForSPL(userText) + '"';

        var search = new SearchManager({
            id: "chat_search_" + Date.now(),
            search: spl,
            autostart: true
        });

        function finish() {
            requestInFlight = false;
            setInputEnabled(true);
            document.getElementById("chat-input").focus();
            search.cancel();
        }

        search.on("search:done", function () {
            var results = search.data("results", { count: 1 });
            results.on("data", function () {
                removeThinkingIndicator();
                var rows = results.collection().models;
                if (rows.length > 0) {
                    appendBubble("assistant", rows[0].get("response"));
                } else {
                    appendBubble("assistant", "(no response received)");
                }
                finish();
            });
        });

        search.on("search:failed", function () {
            removeThinkingIndicator();
            appendBubble("assistant", "(something went wrong — check the search job for errors)");
            finish();
        });
    }

    function handleSendClick() {
        if (requestInFlight) {
            return;
        }
        var input = document.getElementById("chat-input");
        var text = input.value.trim();
        if (text.length === 0) {
            return;
        }
        input.value = "";
        sendMessage(text);
    }

    document.getElementById("send-btn").addEventListener("click", handleSendClick);

    document.getElementById("chat-input").addEventListener("keydown", function (e) {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            handleSendClick();
        }
    });

    document.getElementById("new-chat-btn").addEventListener("click", function () {
        if (requestInFlight) {
            return;
        }
        sessionId = generateSessionId();
        document.getElementById("chat-window").innerHTML = "";
        showWelcomeMessage();
    });

    function showWelcomeMessage() {
        var chatWindow = document.getElementById("chat-window");
        var turn = document.createElement("div");
        turn.className = "chat-turn";

        var bubble = document.createElement("div");
        bubble.className = "chat-bubble assistant";

        var intro = document.createElement("div");
        intro.innerHTML = "<strong>Hi, I'm an AI assistant with limited capabilities.</strong> Here's what I can currently help with:";
        bubble.appendChild(intro);

        var canDoList = document.createElement("ul");
        canDoList.className = "chat-bullet-list";
        [
            "Answering general questions using a local language model",
            "Referencing recent Splunk data when relevant (simple keyword matching, not a full search)",
            "Remembering our conversation, but only within this session"
        ].forEach(function (item) {
            var li = document.createElement("li");
            li.textContent = item;
            canDoList.appendChild(li);
        });
        bubble.appendChild(canDoList);

        var limitsHeading = document.createElement("div");
        limitsHeading.textContent = "A few limits worth knowing up front:";
        bubble.appendChild(limitsHeading);

        var limitsList = document.createElement("ul");
        limitsList.className = "chat-bullet-list";
        [
            "I can't run searches or take any action on my own. I only answer based on what I'm given",
            "My memory resets when you click New Conversation, or if this session is closed",
            "I don't have visibility into your full environment - only what's provided to me here"
        ].forEach(function (item) {
            var li = document.createElement("li");
            li.textContent = item;
            limitsList.appendChild(li);
        });
        bubble.appendChild(limitsList);

        var closing = document.createElement("div");
        closing.textContent = "What would you like to ask?";
        bubble.appendChild(closing);

        turn.appendChild(bubble);
        chatWindow.appendChild(turn);
    }

    // Live status check — runs once on page load. Cheap (short-timeout
    // /api/tags call server-side), so it doesn't meaningfully delay
    // anything, and gives a real answer instead of assuming online.
    function checkLlmStatus() {
        var settled = false;

        // Failsafe: if neither search:done nor search:failed fires
        // within 10 seconds (e.g. the command silently hangs, or an
        // event handler doesn't fire the way expected), stop showing
        // "Checking..." forever and say so plainly instead.
        var timeoutId = setTimeout(function () {
            if (!settled) {
                settled = true;
                document.getElementById("status-dot").className = "status-dot status-offline";
                document.getElementById("status-text").textContent = "Status check timed out";
            }
        }, 10000);

        var statusSearch = new SearchManager({
            id: "status_check_" + Date.now(),
            search: "| ollamachatstatus",
            autostart: true
        });

        statusSearch.on("search:done", function () {
            if (settled) { return; }
            var results = statusSearch.data("results", { count: 1 });
            results.on("data", function () {
                if (settled) { return; }
                settled = true;
                clearTimeout(timeoutId);

                var rows = results.collection().models;
                var dot = document.getElementById("status-dot");
                var text = document.getElementById("status-text");

                if (rows.length === 0) {
                    dot.className = "status-dot status-offline";
                    text.textContent = "Status unknown";
                    statusSearch.cancel();
                    return;
                }

                var row = rows[0];
                var status = row.get("status");
                var model = row.get("configured_model");
                var rawAvailable = row.get("model_available");
                var modelAvailable = rawAvailable === "1" || rawAvailable === "true" || rawAvailable === true;

                if (status === "online" && modelAvailable) {
                    dot.className = "status-dot status-online";
                    text.textContent = "Online — " + model;
                } else if (status === "online") {
                    dot.className = "status-dot status-warning";
                    text.textContent = "Online, but model \"" + model + "\" not found on server";
                } else {
                    dot.className = "status-dot status-offline";
                    text.textContent = "LLM unreachable (configured model: " + model + ")";
                }
                statusSearch.cancel();
            });
        });

        statusSearch.on("search:failed", function () {
            if (settled) { return; }
            settled = true;
            clearTimeout(timeoutId);
            document.getElementById("status-dot").className = "status-dot status-offline";
            document.getElementById("status-text").textContent = "Unable to check LLM status";
            statusSearch.cancel();
        });
    }

    showWelcomeMessage();
    checkLlmStatus();
    forceFullWidthLayout();

    // CSS alone didn't reliably win against Splunk's own dashboard
    // layout styles in testing — this walks up from our known elements
    // and directly strips any width constraint set on ancestor
    // containers, as a more forceful fallback.
    function forceFullWidthLayout() {
        var el = document.getElementById("chatbot-header");
        var hops = 0;
        while (el && hops < 8) {
            el.style.maxWidth = "none";
            el.style.width = "100%";
            el.style.boxSizing = "border-box";
            el = el.parentElement;
            hops++;
        }
    }
});
