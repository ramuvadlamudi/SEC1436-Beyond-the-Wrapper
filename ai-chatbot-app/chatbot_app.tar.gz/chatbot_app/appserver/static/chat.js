// This file runs in the browser when someone opens the chatbot dashboard.
//
// Changes from v1, based on review feedback:
//   - Shows a "thinking..." indicator while waiting for a reply.
//   - Disables Send + the input box while a request is in flight, so you
//     can't double-submit and end up with overlapping searches.
//   - Escaping now handles newlines and other control characters, not
//     just quotes and backslashes — multiline paste was able to break
//     the SPL string before.
//   - Cancels each SearchManager's job after reading its result, so
//     completed chat searches don't sit around as orphaned jobs.
//   - Renders ``` code blocks as <pre> so SPL/code in replies is
//     actually readable instead of one run-on paragraph.

require([
    "splunkjs/mvc/searchmanager",
    "splunkjs/mvc/simplexml/ready!"
], function (SearchManager) {

    var sessionId = generateSessionId();
    var requestInFlight = false;

    function generateSessionId() {
        return "sess-" + Date.now() + "-" + Math.floor(Math.random() * 100000);
    }

    // Escapes a string for safe embedding inside a double-quoted SPL
    // literal. Handles backslashes and quotes (as before), plus
    // newlines/carriage returns/tabs, which previously could break the
    // generated search string if someone pasted multiline text.
    function escapeForSPL(text) {
        return text
            .replace(/\\/g, "\\\\")
            .replace(/"/g, '\\"')
            .replace(/\r\n/g, "\\n")
            .replace(/\n/g, "\\n")
            .replace(/\r/g, "\\n")
            .replace(/\t/g, "    ");
    }

    // Very small, deliberately limited markdown-ish renderer: turns
    // ```fenced blocks``` into <pre>, and leaves everything else as
    // plain text. Not a full markdown parser — just enough to make SPL
    // and code snippets in replies readable.
    function renderReplyContent(container, text) {
        var parts = text.split(/```/);
        parts.forEach(function (part, index) {
            if (index % 2 === 1) {
                var pre = document.createElement("pre");
                pre.className = "chat-code-block";
                pre.textContent = part.trim();
                container.appendChild(pre);
            } else if (part.trim().length > 0) {
                var p = document.createElement("div");
                p.textContent = part;
                container.appendChild(p);
            }
        });
    }

    function appendBubble(role, text) {
        var chatWindow = document.getElementById("chat-window");
        var bubble = document.createElement("div");
        bubble.className = "chat-bubble " + role;
        if (role === "assistant") {
            renderReplyContent(bubble, text);
        } else {
            bubble.textContent = text;
        }
        chatWindow.appendChild(bubble);
        chatWindow.scrollTop = chatWindow.scrollHeight;
        return bubble;
    }

    function appendThinkingIndicator() {
        var chatWindow = document.getElementById("chat-window");
        var bubble = document.createElement("div");
        bubble.className = "chat-bubble assistant thinking";
        bubble.id = "thinking-indicator";
        bubble.textContent = "Thinking...";
        chatWindow.appendChild(bubble);
        chatWindow.scrollTop = chatWindow.scrollHeight;
    }

    function removeThinkingIndicator() {
        var el = document.getElementById("thinking-indicator");
        if (el) {
            el.parentNode.removeChild(el);
        }
    }

    function setInputEnabled(enabled) {
        document.getElementById("chat-input").disabled = !enabled;
        document.getElementById("send-btn").disabled = !enabled;
    }

    function sendMessage(userText) {
        if (requestInFlight) {
            return; // guard against double-submit
        }
        requestInFlight = true;
        setInputEnabled(false);

        appendBubble("user", userText);
        appendThinkingIndicator();

        var spl = '| ollamachat session_id="' + sessionId +
                   '" user_message="' + escapeForSPL(userText) + '"';

        var search = new SearchManager({
            id: "chat_search_" + Date.now(),
            search: spl,
            autostart: true
        });

        function finish() {
            requestInFlight = false;
            setInputEnabled(true);
            document.getElementById("chat-input").focus();
            // Release the search job now that we're done with it, so
            // finished chat searches don't accumulate on the server.
            search.cancel();
        }

        search.on("search:done", function () {
            var results = search.data("results", { count: 1 });
            results.on("data", function () {
                removeThinkingIndicator();
                var rows = results.collection().models;
                if (rows.length > 0) {
                    appendBubble("assistant", rows[0].get("response"));
                } else {
                    appendBubble("assistant", "(no response received)");
                }
                finish();
            });
        });

        search.on("search:failed", function () {
            removeThinkingIndicator();
            appendBubble("assistant", "(something went wrong — check the search job for errors)");
            finish();
        });
    }

    function handleSendClick() {
        if (requestInFlight) {
            return;
        }
        var input = document.getElementById("chat-input");
        var text = input.value.trim();
        if (text.length === 0) {
            return;
        }
        input.value = "";
        sendMessage(text);
    }

    document.getElementById("send-btn").addEventListener("click", handleSendClick);

    document.getElementById("chat-input").addEventListener("keydown", function (e) {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            handleSendClick();
        }
        // Shift+Enter falls through to the browser's default behaviour,
        // inserting a newline — lets people write multiline questions.
    });

    document.getElementById("new-chat-btn").addEventListener("click", function () {
        if (requestInFlight) {
            return;
        }
        sessionId = generateSessionId();
        document.getElementById("chat-window").innerHTML = "";
        showWelcomeMessage();
    });

    // Shown once when the dashboard first loads, and again after "New
    // Conversation" — static, not LLM-generated, so it's instant and
    // always says exactly the same thing. Kept in sync by hand with the
    // greeting text ollamachat.py returns for simple "hi"/"hello"
    // messages, so the two paths feel consistent to the user.
    function showWelcomeMessage() {
        var chatWindow = document.getElementById("chat-window");
        var bubble = document.createElement("div");
        bubble.className = "chat-bubble assistant";

        var intro = document.createElement("div");
        intro.innerHTML = "<strong>Hi, I'm an AI assistant with limited capabilities.</strong> Here's what I can currently help with:";
        bubble.appendChild(intro);

        var canDoList = document.createElement("ul");
        canDoList.className = "chat-bullet-list";
        [
            "Answering general questions using a local language model",
            "Referencing recent Splunk data when relevant (simple keyword matching, not a full search)",
            "Remembering our conversation, but only within this session"
        ].forEach(function (item) {
            var li = document.createElement("li");
            li.textContent = item;
            canDoList.appendChild(li);
        });
        bubble.appendChild(canDoList);

        var limitsHeading = document.createElement("div");
        limitsHeading.textContent = "A few limits worth knowing up front:";
        bubble.appendChild(limitsHeading);

        var limitsList = document.createElement("ul");
        limitsList.className = "chat-bullet-list";
        [
            "I can't run searches or take any action on my own — only answer based on what I'm given",
            "My memory resets when you click New Conversation, or if this session is closed",
            "I don't have visibility into your full environment — only what's provided to me here"
        ].forEach(function (item) {
            var li = document.createElement("li");
            li.textContent = item;
            limitsList.appendChild(li);
        });
        bubble.appendChild(limitsList);

        var closing = document.createElement("div");
        closing.textContent = "What would you like to ask?";
        bubble.appendChild(closing);

        chatWindow.appendChild(bubble);
    }

    showWelcomeMessage();
});
